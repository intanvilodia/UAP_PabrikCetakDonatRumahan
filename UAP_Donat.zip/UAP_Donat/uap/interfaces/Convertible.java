package uap.interfaces;

//interface ini saya gunakan untuk mengonversi massa dari gram ke kilogram
public interface Convertible {
    double toKilogram(); //method konversi wajib diimplementasi
}