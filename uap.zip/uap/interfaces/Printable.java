package uap.interfaces;

//interface ini saya gunakan agar setiap cetakan wajib bisa menampilkan info perhitungannya
public interface Printable {
    void printInfo(); //method yang wajib diimplementasi untuk mencetak informasi
}